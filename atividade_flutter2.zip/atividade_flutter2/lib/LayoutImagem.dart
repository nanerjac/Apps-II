import 'package:flutter/material.dart';
import 'package:atividade_flutter2/LayoutCard.dart';

class LayoutImagem extends StatelessWidget {
  const LayoutImagem({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("Imagem"),
          backgroundColor: Colors.deepPurple,
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              Text(
                "App feito na linguagem Dart",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 30,
                  fontStyle: FontStyle.normal,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 30),
                child: Image.asset('images/dart.jpg'),
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 30),
                child: RaisedButton(
                  padding: EdgeInsets.all(15),
                  child: Text(
                    "Conhecer outras linguagens",
                    style: TextStyle(fontSize: 15),
                  ),
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => LayoutCard()));
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
