import 'package:flutter/material.dart';

class LayoutCard extends StatelessWidget {
  const LayoutCard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("Cards"),
          backgroundColor: Colors.deepPurple,
        ),
        body: CustomScrollView(
          slivers: <Widget>[
            SliverList(
              delegate: SliverChildBuilderDelegate((BuildContext context, int index) {
                return Container(
                  alignment: Alignment.center,
                  child: Column(
                    children: <Widget>[
                      //Imagem 1
                      Padding(
                        padding: EdgeInsets.only(bottom: 30),
                        child: Image.asset('images/java-logo.png'),
                      ),
                      Padding(
                        padding: EdgeInsets.only(bottom: 30),
                        child: RaisedButton(
                            padding: EdgeInsets.all(15),
                            child: Text(
                              "Saiba mais sobre Java",
                              style: TextStyle(fontSize: 15),
                            ),
                            onPressed: () {}
                        ),
                      ),
                      //Imagem 2
                      Padding(
                        padding: EdgeInsets.only(bottom: 30),
                        child: Image.asset('images/c#.png'),
                      ),
                      Padding(
                        padding: EdgeInsets.only(bottom: 30),
                        child: RaisedButton(
                            padding: EdgeInsets.all(15),
                            child: Text(
                              "Saiba mais sobre C#",
                              style: TextStyle(fontSize: 15),
                            ),
                            onPressed: () {}
                        ),
                      ),
                      //Imagem 3
                      Padding(
                        padding: EdgeInsets.only(bottom: 30),
                        child: Image.asset('images/python.png'),
                      ),
                      Padding(
                        padding: EdgeInsets.only(bottom: 30),
                        child: RaisedButton(
                            padding: EdgeInsets.all(15),
                            child: Text(
                              "Saiba mais sobre Python",
                              style: TextStyle(fontSize: 15),
                            ),
                            onPressed: () {}
                        ),
                      ),
                      //Botão voltar
                      Padding(
                        padding: EdgeInsets.only(bottom: 30),
                        child: RaisedButton(
                            padding: EdgeInsets.all(15),
                            child: Text(
                              "Voltar",
                              style: TextStyle(fontSize: 15),
                            ),
                            onPressed: () {
                              Navigator.pop(context);
                            }
                        ),
                      ),
                    ],
                  ),
                );
              },
            )),
          ],
        ),
      ),
    );
  }
}
