package com.example.atividade_flutter2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
