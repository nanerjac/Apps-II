import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    title: 'Fórmula Um',
    theme: ThemeData(
      primarySwatch: Colors.red,
    ),
    home: MyApp(),
  ));
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Velocidade"),
      ),
      body: Container(
          padding: EdgeInsets.all(16),
          child: Column(
            children: [
              Center(
              child: Image.asset("images/logo.jpg", fit: BoxFit.fill,),
              ),
              Padding(padding: EdgeInsets.all(50),
              ),
              //ignore: deprecated_member_use
              RaisedButton(
                  child: Text("Próxima Tela"),
                  color: Colors.red,
                  padding: EdgeInsets.all(20),
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => Informacoes()));
                  })
            ],
          )
      ),
    );
  }
}

class Informacoes extends StatelessWidget {
  const Informacoes({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pilotos'),
      ),
      body: ListView(
        children: [
          ListTile(
            leading: Icon(Icons.car_rental),
            title: Text('Carros'),
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => Carros()));
            },
          ),
          ListTile(
            leading: Icon(Icons.account_tree),
            title: Text('Equipes'),
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => Equipes()));
            }
          ),
          ListTile(
              leading: Icon(Icons.person),
              title: Text('Pilotos'),
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => Pilotos()));
              }
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.push(context,
                MaterialPageRoute(builder: (context) => Grid2021()));
            },
            child: Text('Pilotos de 2021'),
          ),
          Image.asset(
            "images/principal.jpg",
            scale: 0.6,
          ),
          Padding(padding: EdgeInsets.all(10)),
          Center(
            child: ElevatedButton.icon(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: Icon(Icons.arrow_back),
              label: Text('Voltar'),
            ),
          ),
          Padding(padding: EdgeInsets.all(20)),
        ],
      ),
    );
  }
}

class Carros extends StatelessWidget {
  const Carros({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Carro F1'),
      ),
      body: ListView(
        children: [
          Center(
            child: Text(
              'Carros 2021',
              style: TextStyle(fontSize: 45),
            ),
          ),
          Center(
            child: Text(
              'Mercedes AMG',
              style: TextStyle(fontSize: 30),
            ),
          ),
          Padding(padding: EdgeInsets.all(100),
            child: Image.asset("images/benz.jpg"),
          ),
          Center(
            child: Text(
              'Ferrari',
              style: TextStyle(fontSize: 30),
            ),
          ),
          Padding(padding: EdgeInsets.all(100),
            child: Image.asset("images/sf.jpg"),
          ),
          Center(
            child: Text(
              'RBR RedBull',
              style: TextStyle(fontSize: 30),
            ),
          ),
          Padding(padding: EdgeInsets.all(100),
            child: Image.asset("images/redbull.jpg"),
          ),
          Center(
            child: Text(
              'McLaren',
              style: TextStyle(fontSize: 30),
            ),
          ),
          Padding(padding: EdgeInsets.all(100),
            child: Image.asset("images/ml.jpg"),
          ),
          Center(
            child: ElevatedButton.icon(
              onPressed: (){
                Navigator.pop(context);
              },
              icon: Icon(Icons.arrow_back),
              label: Text("Voltar"),
            ),
          ),
          Padding(padding: EdgeInsets.all(20)),
        ],
      ),
    );
  }
}

class Equipes extends StatelessWidget {
  const Equipes({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Equipes F1'),
      ),
      body: ListView(
        children: [
          Center(
            child: Text(
              'Equipes 2021',
              style: TextStyle(fontSize: 45),
            ),
          ),
          Center(
            child: Text(
              'Mercedes AMG',
              style: TextStyle(fontSize: 30),
            ),
          ),
          Padding(padding: EdgeInsets.all(10),
            child: Image.asset("images/mercedes.png"),
          ),
          Center(
            child: Text(
              'Ferrari',
              style: TextStyle(fontSize: 30),
            ),
          ),
          Padding(padding: EdgeInsets.all(10),
            child: Image.asset("images/ferrari.png"),
          ),
          Center(
            child: Text(
              'RBR RedBull',
              style: TextStyle(fontSize: 30),
            ),
          ),
          Padding(padding: EdgeInsets.all(10),
            child: Image.asset("images/rbr.jpg"),
          ),
          Center(
            child: Text(
              'McLaren',
              style: TextStyle(fontSize: 30),
            ),
          ),
          Padding(padding: EdgeInsets.all(10),
            child: Image.asset("images/mclaren.png"),
          ),
          Center(
            child: ElevatedButton.icon(
              onPressed: (){
                Navigator.pop(context);
              },
              icon: Icon(Icons.arrow_back),
              label: Text("Voltar"),
            ),
          ),
          Padding(padding: EdgeInsets.all(20)),
        ],
      ),
    );
  }
}

class Pilotos extends StatelessWidget {
  const Pilotos({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pilotos F1'),
      ),
      body: ListView(
        children: [
          Center(
            child: Text(
              'Pilotos 2021',
              style: TextStyle(fontSize: 45),
            ),
          ),
          Center(
            child: Text(
              'Lewis Hamilton',
              style: TextStyle(fontSize: 30),
            ),
          ),
          Padding(padding: EdgeInsets.all(10),
            child: Image.asset("images/Hamilton.jpg"),
          ),
          Center(
            child: Text(
              'Max Verstappen',
              style: TextStyle(fontSize: 30),
            ),
          ),
          Padding(padding: EdgeInsets.all(10),
            child: Image.asset("images/Verstappen.jpg"),
          ),
          Center(
            child: Text(
              'Charles Leclerc',
              style: TextStyle(fontSize: 30),
            ),
          ),
          Padding(padding: EdgeInsets.all(10),
            child: Image.asset("images/Leclerc.jpg"),
          ),
          Center(
            child: Text(
              'Lando Norris',
              style: TextStyle(fontSize: 30),
            ),
          ),
          Padding(padding: EdgeInsets.all(10),
            child: Image.asset("images/Norris.jpg"),
          ),
          Center(
            child: ElevatedButton.icon(
              onPressed: (){
                Navigator.pop(context);
              },
              icon: Icon(Icons.arrow_back),
              label: Text("Voltar"),
            ),
          ),
          Padding(padding: EdgeInsets.all(20)),
        ],
      ),
    );
  }
}

class Grid2021 extends StatelessWidget {
  const Grid2021({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Grid Completo F1 2021'),
      ),
      body: ListView(
        children: [
          Center(
            child: Text(
              'Grid 2021',
              style: TextStyle(fontSize: 45),
            ),
          ),
          Center(
            child: Text(
              'Grid Completo',
              style: TextStyle(fontSize: 30),
            ),
          ),
          Padding(padding: EdgeInsets.all(10),
            child: Image.asset("images/grid.jpg"),
          ),
          Center(
            child: ElevatedButton.icon(
              onPressed: (){
                Navigator.pop(context);
              },
              icon: Icon(Icons.arrow_back),
              label: Text("Voltar"),
            ),
          ),
          Padding(padding: EdgeInsets.all(20)),
        ],
      ),
    );
  }
}