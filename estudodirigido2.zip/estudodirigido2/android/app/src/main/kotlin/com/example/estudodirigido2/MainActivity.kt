package com.example.estudodirigido2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
